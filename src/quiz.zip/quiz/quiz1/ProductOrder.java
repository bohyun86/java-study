package quiz.quiz1;

public class ProductOrder {
    String productName;
    int price;
    int quantity;
}
